//
//  HawcxFramework.h
//  HawcxFramework
//
//  Created by dev on 10/15/24.
//

#import <Foundation/Foundation.h>

//! Project version number for HawcxFramework.
FOUNDATION_EXPORT double HawcxFrameworkVersionNumber;

//! Project version string for HawcxFramework.
FOUNDATION_EXPORT const unsigned char HawcxFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HawcxFramework/PublicHeader.h>
